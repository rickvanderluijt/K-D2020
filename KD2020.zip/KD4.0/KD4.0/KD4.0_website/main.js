angular.module('KRRclass', [ 'chart.js']).controller('MainCtrl', ['$scope','$http', mainCtrl]);

const buttons = document.querySelectorAll('#animbutton')
buttons.forEach(btn => {
  btn.addEventListener('click', function(e) {

    let x = e.clientX - e.target.offsetLeft;
    let y = e.clientY - e.target.offsetTop;

    let ripples = document.createElement('span')
    ripples.style.left = x + 'px';
    ripples.style.top = y + 'px';
    this.appendChild(ripples);

    setTimeout(() => {
      ripples.remove()
    },1000);
  })
})



function show(divId) {
     $("#" + divId).show();
 }

 function GFG_Fun() {
     show('myCollapsible');
     $('#GFG_DOWN').text("DIV Box is visible.");
       }

function show(divId) {
    $("#" + divId).show();
}

function GFG_Fun2() {
    show('myCollapsible2');
    $('#GFG_DOWN').text("DIV Box is visible.");
}


function mainCtrl($scope, $http){

	$scope.optionGenres = ["Adult standards", "Blues", "Rock", "Pop", "Jazz", "Dance", "Hip-hop", ];
	$scope.yesNo = ["Yes", "No", ];
	$scope.years = ["50's", "60's","70's","80's","90's","00's","10's", ];
	$scope.number = ["5", "10","15", "20", "25", "All"];



	$scope.startMyAwesomeApp = function(){
		// $scope.myGenre =
		// $scope.myYear =
    if ( $scope.selectedGenre == "Adult standards" )  {
        $scope.selectedGenre1 = "adult standards"
    } else if ( $scope.selectedGenre == "Blues" )  {
        $scope.selectedGenre1 = "blues"
    } else if ( $scope.selectedGenre == "Rock" )  {
        $scope.selectedGenre1 = "rock"
    } else if ( $scope.selectedGenre == "Pop" )  {
        $scope.selectedGenre1 = "pop"
    } else if ( $scope.selectedGenre == "Jazz" )  {
        $scope.selectedGenre1 = "jazz"
    } else if ( $scope.selectedGenre == "Dance" )  {
        $scope.selectedGenre1= "dance"
    } else if ( $scope.selectedGenre == "Hip-hop" )  {
        $scope.selectedGenre1 = "hip hop"
      }

		$scope.selectedGenre2 = encodeURI($scope.selectedGenre1).replace(/#/g, '%23');
    //!!! Make sure to change mySparqlEndpoint to the correct one. This link can be found when the ttl. file is uploaded to GraphDb. !!!
		$scope.mySparqlEndpoint = "http://192.168.1.39:7200/repositories/ProjectFinal2" ;
		$scope.myInputQuery = `PREFIX ex: <http://example/music/>
PREFIX music: <http://www.semanticweb.org/rickv/ontologies/2020/9/Music#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?song5 ?artist5 ?length ?hasReleaseYear
    WHERE{
    ?song music:hasGenre ex:`+ $scope.selectedGenre2+ `;
          music:hasReleaseYear ?hasReleaseYear;
          music:hasLength ?length ;
          music:hasArtist ?artist .

			FILTER ( ?hasReleaseYear = "`+ $scope.myYear+`"^^xsd:integer)

		  BIND(REPLACE(STR(?song4), "%29", ")") AS ?song5) .
			BIND(REPLACE(STR(?artist4), "%29", ")") AS ?artist5) .
			BIND(REPLACE(STR(?length4), "%29", ")") AS ?length5) .
			BIND(REPLACE(STR(?song3), "%28", "(") AS ?song4) .
		  BIND(REPLACE(STR(?artist3), "%28", "(") AS ?artist4) .
		  BIND(REPLACE(STR(?length3), "%28", "(") AS ?length4) .
			BIND(REPLACE(STR(?song2), "%27", "'") AS ?song3) .
		 	BIND(REPLACE(STR(?artist2), "%27", "'") AS ?artist3) .
		  BIND(REPLACE(STR(?length2), "%27", "'") AS ?length3) .
			BIND(REPLACE(STR(?song1), "%20", " ") AS ?song2) .
    	BIND(REPLACE(STR(?artist1), "%20", " ") AS ?artist2) .
    	BIND(REPLACE(STR(?length1), "%20", " ") AS ?length2) .
   		BIND( STRAFTER(STR(?song),STR(ex:)) AS ?song1  )
    	BIND( STRAFTER(STR(?artist),STR(ex:)) AS ?artist1  )
    	BIND( STRAFTER(STR(?length),STR(ex:)) AS ?length1  )


}`;
		$scope.mySparqlQuery = encodeURI($scope.myInputQuery).replace(/#/g, '%23');
		console.log($scope.mySparqlQuery)
		$http( {
			method: "GET",
			url : $scope.mySparqlEndpoint + "?query=" + $scope.mySparqlQuery,
			headers : {'Accept':'application/sparql-results+json', 'Content-Type':'application/sparql-results+json'}
		} )
		.success(function(data, status) {
			$scope.myDynamicLabels = [];
			$scope.myDynamicDataSong = [];
			$scope.myDynamicDataArtist = [];
			$scope.myDynamicDataLength = [];
			// $scope.myDynamicData = data.data.head
			console.log(data)
			$scope.myData = data.results.bindings
			// .then(function (data) {$scope.names = response.data.records;});

			// now iterate on the results

			angular.forEach(data.results.bindings, function(val) {
				$scope.myDynamicDataSong.push(val.song.value);
				$scope.myDynamicDataArtist.push(val.artist.value);
				$scope.myDynamicDataLength.push(val.length.value);
			console.log($scope.myDynamicDataSong)
			});
		})
		.error(function(error ){
			console.log('Error running the input query!'+error);
		});

	};


$scope.startMyAwesomeApp2 = function(){
	$scope.award = ""
	$scope.yearB = ""
	$scope.yearE = ""



	if (( $scope.selectedAward == "Yes" ) || ( $scope.selectedAward == "yes" )) {
			$scope.award = "FILTER ( ?award > \"0\"^^xsd:integer)";
		} else {
			$scope.award = "";
		}

if (( $scope.selectedProducer == "Yes" ) || ( $scope.selectedProducer == "yes" )) {
		$scope.producer = "?producer music:hasProducerName ?ProducerName .";
	} else {
		$scope.producer = "";
	}

if ( $scope.selectedYears == "50's" )  {
		$scope.yearB = "FILTER ( ?hasReleaseYear >= \"1950\"^^xsd:integer)"
		$scope.yearE = "FILTER ( \"1959\"^^xsd:integer >= ?hasReleaseYear)"
} else if ( $scope.selectedYears == "60's" ) {
		$scope.yearB = "FILTER ( ?hasReleaseYear >= \"1960\"^^xsd:integer)"
		$scope.yearE = "FILTER ( \"1969\"^^xsd:integer >= ?hasReleaseYear)"
} else if ( $scope.selectedYears == "70's" ) {
		$scope.yearB = "FILTER ( ?hasReleaseYear >= \"1970\"^^xsd:integer)"
		$scope.yearE = "FILTER ( \"1979\"^^xsd:integer >= ?hasReleaseYear)"
} else if ( $scope.selectedYears == "80's" ) {
		$scope.yearB = "FILTER ( ?hasReleaseYear >= \"1980\"^^xsd:integer)"
		$scope.yearE = "FILTER ( \"1989\"^^xsd:integer >= ?hasReleaseYear)"
} else if ( $scope.selectedYears == "90's" ) {
		$scope.yearB = "FILTER ( ?hasReleaseYear >= \"1990\"^^xsd:integer)"
		$scope.yearE = "FILTER ( \"1999\"^^xsd:integer >= ?hasReleaseYear)"
} else if ( $scope.selectedYears == "00's" ) {
		$scope.yearB = "FILTER ( ?hasReleaseYear >= \"2000\"^^xsd:integer)"
		$scope.yearE = "FILTER ( \"2009\"^^xsd:integer >= ?hasReleaseYear)"
} else if ( $scope.selectedYears == "10's" ) {
		$scope.yearB = "FILTER ( ?hasReleaseYear >= \"2010\"^^xsd:integer)"
		$scope.yearE = "FILTER ( \"2019\"^^xsd:integer >= ?hasReleaseYear)"
}

if ( $scope.limit == "All" ) {
	$scope.limit = ""
} else {
	$scope.limit = "LIMIT "+$scope.limit+""

}

	$scope.myGenreAlbum1 = encodeURI($scope.myGenreAlbum).replace(/#/g, '%23');
    //!!! Make sure to change mySparqlEndpoint to the correct one. This link can be found when the ttl. file is uploaded to GraphDb. !!!
	$scope.mySparqlEndpointAlbum = "http://192.168.1.39:7200/repositories/ProjectFinal2" ;
	$scope.myInputQueryAlbum = `
  PREFIX ex: <http://example/music/>
  PREFIX music: <http://www.semanticweb.org/rickv/ontologies/2020/9/Music#>
  PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
  PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
  PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>

  SELECT DISTINCT ?AlbumName ?AlbumName1	?ArtistName1	?ProducerName ?award ?cover1 ?birthPlaceName ?hasReleaseYear
	WHERE{
	?album music:hasGenre ex:`+ $scope.myGenreAlbum1+` ;
		   music:hasReleaseYear ?hasReleaseYear ;
		   music:hasArtist ?artist ;
		   music:hasAlbumCover ?cover ;
       music:hasProducer ?producer ;
		   music:wonAward ?award ;
    	   music:hasAlbumName ?AlbumName .
    ?artist music:hasArtistName ?ArtistName ;
    		music:fromCountry ?birthPlace .
    `+$scope.producer+`
    ?birthPlace music:hasBirthPlaceName ?birthPlaceName

    `+$scope.yearB+`
    `+$scope.yearE+`
    `+$scope.award+`

     BIND(REPLACE(STR(?ArtistName), "_", " ") AS ?ArtistName1) .
     BIND(REPLACE(STR(?AlbumName), "_", " ") AS ?AlbumName1) .
     BIND( STRAFTER(STR(?cover),STR(ex:)) AS ?cover1  ) .

} `+$scope.limit+` `;



	$scope.mySparqlQueryAlbum = encodeURI($scope.myInputQueryAlbum).replace(/#/g, '%23');
	console.log(	$scope.mySparqlQueryAlbum)
	$http( {
		method: "GET",
		url : $scope.mySparqlEndpointAlbum + "?query=" + $scope.mySparqlQueryAlbum,
		headers : {'Accept':'application/sparql-results+json', 'Content-Type':'application/sparql-results+json'}
	} )
	.success(function(data, status) {
		console.log(data)
		$scope.myDataAlbum = data.results.bindings
// now iterate on the results

	})
	.error(function(error ){
		console.log('Error running the input query!'+error);
	});

};
};




// var app = angular.module('myApp', []);
// app.controller('customersCtrl', function($scope, $http) {
//     $http.get("customers.php")
//     .then(function (response) {$scope.names = response.data.records;});
// });
